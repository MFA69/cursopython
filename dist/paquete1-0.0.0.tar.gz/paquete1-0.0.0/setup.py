
from setuptools import setup

setup (
    name = "paquete1")
    
    
